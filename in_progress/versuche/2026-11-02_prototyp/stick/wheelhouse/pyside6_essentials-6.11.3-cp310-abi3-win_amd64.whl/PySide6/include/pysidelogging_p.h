// Copyright (C) 2022 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#ifndef PYSIDE_LOGGING_P_H
#define PYSIDE_LOGGING_P_H

#include <QtCore/qloggingcategory.h>

Q_DECLARE_LOGGING_CATEGORY(lcPySide)

#endif // PYSIDE_LOGGING_P_H
