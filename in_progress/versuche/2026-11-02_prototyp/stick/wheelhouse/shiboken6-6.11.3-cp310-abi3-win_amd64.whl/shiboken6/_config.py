shiboken_library_soversion = "6.11"

version = "6.11.3"
version_info = (6, 11, 3, "", "")

__build_date__ = '2026-10-22T06:10:26+00:00'




__setup_py_package_version__ = '6.11.3'

